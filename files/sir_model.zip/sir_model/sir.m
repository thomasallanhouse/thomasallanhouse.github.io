function dp = sir(t,p,beta,gamma)
dp = zeros(3,1);
dp(1) = -beta*p(1)*p(2);
dp(2) = beta*p(1)*p(2) - gamma*p(2);
dp(3) = gamma*p(2);
end
