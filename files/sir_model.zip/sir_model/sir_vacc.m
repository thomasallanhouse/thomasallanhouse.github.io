function [] = sir_vacc(R0,T,V)
% Plot SIR curves for an SIR epidemic with vaccination

i0=1e-6;
gamma=1/T;
beta = R0*gamma;

odefun = @(t,p) sir(t,p,beta,gamma);

p_init = (1-V)*[1-i0, i0, 0];
tspan = [0 T];
ii=1;
ST=[]; SP=[];
jj=0;
while (ii > i0)
    [st, sp] = ode45 ( odefun, tspan , p_init );
    ii=sp(end,2);
    p_init=sp(end,:);
    ST=[ST;(st + jj*T)];
    SP=[SP;sp];
    jj=jj+1;
end

% cla
hold on
plot(ST,SP(:,1),'k','LineWidth',2)
plot(ST,SP(:,2),'r','LineWidth',2)
plot(ST,SP(:,3),'b','LineWidth',2)
plot([ST(1) ST(end)],[V V],'m','LineWidth',2)
hold off

set(gca,'FontSize',14);
legend({'Susceptible','Infectious','Recovered','Vaccinated'},...
    'Location','EastOutside','Orientation','vertical','FontSize',12)
xlabel('Time (days)')
ylabel('Proportion of Population')
title(['R_0 = ' num2str(R0) '; T = ' num2str(T) '; V = ' num2str(V) '.']);
% set(get(gca,'xlabel'),'FontSize',16);
% set(get(gca,'ylabel'),'FontSize',16);
xlim([0 jj*T])
ylim([0 1])
box on

end


