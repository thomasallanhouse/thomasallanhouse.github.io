#!/usr/bin/env python

from setuptools import setup, find_packages

setup(name='households',
      version='0.1',
      description='Infectious disease transmission in households',
      author=['Rosalind Eggo', 'Thomas House', 'Lorenzo Pellis', 'William Waites'],
      author_email='william.waites@strath.ac.uk',
      keywords=['epidemics', 'likelihood', 'households'],
      classifiers=[
          # How mature is this project? Common values are
          #   3 - Alpha
          #   4 - Beta
          #   5 - Production/Stable
          'Development Status :: 3 - Alpha',

          # Intended audience
          'Intended Audience :: Education',
          'Intended Audience :: Science/Research',

          # License
          #'License :: OSI Approved :: GNU General Public License (GPL)',
          # Specify the Python versions you support here. In particular,
          # ensure that you indicate whether you support Python 2, Python 3
          # or both.
          'Programming Language :: Python :: 3',
      ],
      license='GPLv3',
      packages=find_packages(),
      install_requires=[
          'networkx',
          'scipy',
      ],
      python_requires='>=3.1.*',

      ##
      ## if anything in entry_points changes, it is necessary to run
      ##
      ##     python setup.py develop
      ## or
      ##     python setup.py install
      ##
      ## (as appropriate) again
      ##
      entry_points={
         'console_scripts': [
              'households = households.command:cli',
          ],
      },
)
