# Household Transmission Model

## Installation

A convenient way to install this software is using [Anaconda]. You can
also use any virtual environment manager instead so long as you end up
with an environment that has

* SciPy    (needed for running the model)
* NetworkX (needed for reading GraphML files containing a 
  representation of the population)

Using [Anaconda], the sequence looks like this:

    conda create -y -n households python=3
    conda activate households
    conda install -y scipy networkx

Finally, one can do either:

    python setup.py develop

or

    python setup.py install

according to whether a development environment (where you can change
files in this directory and they will get used by the program) or a
production installation (where the program is copied from this directory,
so no subsequent changes here will perturb the software).

## Usage

This package provides a command-line tool called `households`. It takes various
arguments for setting up the optimisation and produces two output files, by
default called `fit-best.json` and `fit-history.csv` and logs its progress to
the standard output. The program accepts the standard `--help` argument to find
out how to run it.

Example usage:

    % households -i minimal-orthodox.graphml --fit lambdaG,lambdaL
    2022-08-18 10:31:32,588 INFO Reading Orthodox format graphical data from minimal-orthodox.graphml
    2022-08-18 10:31:32,663 INFO Discarding 123 of 374 total households
    2022-08-18 10:31:32,663 INFO Computing possible outcomes for each household
    2022-08-18 10:31:32,685 INFO Qualities and covariates:
    2022-08-18 10:31:32,685 INFO     liq: ('age', 'sex')
    2022-08-18 10:31:32,685 INFO     lig: (((0, 1), (2, 3), (4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14)), ('male', 'female'))
    2022-08-18 10:31:32,685 INFO     loq: ('serology', 'positive')
    2022-08-18 10:31:32,685 INFO     log: ((False, True), (False, True))
    2022-08-18 10:31:32,685 INFO     niq: 2
    2022-08-18 10:31:32,686 INFO     nig: [3 2]
    2022-08-18 10:31:32,686 INFO     nit: 6
    2022-08-18 10:31:32,686 INFO     nirg: [2 1]
    2022-08-18 10:31:32,686 INFO     nic: 3
    2022-08-18 10:31:32,686 INFO     noq: 2
    2022-08-18 10:31:32,686 INFO Fixed parameters:
    2022-08-18 10:31:32,686 INFO     shape: 1.0
    2022-08-18 10:31:32,686 INFO     eta: 1.0
    2022-08-18 10:31:32,686 INFO     alpha: [1. 1. 1.]
    2022-08-18 10:31:32,686 INFO     beta: [1. 1. 1.]
    2022-08-18 10:31:32,686 INFO     gamma: [1. 1. 1.]
    2022-08-18 10:31:32,686 INFO Fitting ['lambdaG', 'lambdaL']
    2022-08-18 10:31:32,686 INFO Initial conditions:
    2022-08-18 10:31:32,686 INFO     lambdaG: -1.0
    2022-08-18 10:31:32,686 INFO     lambdaL: -1.0
    2022-08-18 10:31:32,686 INFO Maximising within bounds
    2022-08-18 10:31:32,686 INFO     lambdaG: [-5.  0.]
    2022-08-18 10:31:32,686 INFO     lambdaL: [-5.  0.]
    2022-08-18 10:31:39,771 INFO Iteration 5 NLL=4449.851054100514
    2022-08-18 10:31:39,771 INFO     lambdaG: -0.413072251535342
    2022-08-18 10:31:39,771 INFO     lambdaL: -1.6791883379591017
    2022-08-18 10:31:46,827 INFO Iteration 10 NLL=4448.602737828194
    2022-08-18 10:31:46,827 INFO     lambdaG: -0.4116366126208333
    2022-08-18 10:31:46,827 INFO     lambdaL: -1.8761451806144438
    2022-08-18 10:31:54,891 INFO Iteration 15 NLL=4447.84676337684
    2022-08-18 10:31:54,891 INFO     lambdaG: -0.3810891784173842
    2022-08-18 10:31:54,891 INFO     lambdaL: -2.0601823679536158
    2022-08-18 10:32:01,948 INFO Iteration 20 NLL=4447.81625405726
    2022-08-18 10:32:01,948 INFO     lambdaG: -0.3744016005303024
    2022-08-18 10:32:01,948 INFO     lambdaL: -2.1255557868072597
    2022-08-18 10:32:05,976 INFO Iteration 22 NLL=4447.816221224032
    2022-08-18 10:32:05,976 INFO     lambdaG: -0.3745554370593328
    2022-08-18 10:32:05,976 INFO     lambdaL: -2.1255670537615456
    2022-08-18 10:32:05,976 INFO Success!
    2022-08-18 10:32:05,976 INFO Writing output
    2022-08-18 10:32:05,976 INFO     fit-best.json
    2022-08-18 10:32:05,978 INFO     fit-history.csv
    

## Internal representation of households

Households are represented as a dictionary. The keys of the dictionary
and their types are:

* `index`: a unique household identifier, any type supporting comparison
* `members`: list of household member identifiers
* `size`: household size, integer. equal to `len(members)`
* `type_of_members`: integer array of member types. a member type is a
  number representing the unique combination of features of an individual
* `age_of_members`: integer array of age classes for each member
* `sex_of_members`: integer array of sex classes for each member
* `serology`: boolean array indicating availability or lack of serology 
  for each member
* `positive`: boolean array indicating serology result for each member
  (False for those members with no serology)
* `outcome_types`: array of XXX fixme

Additionally the preprocessing computes additional keys. It is not the
responsibility of the data reading routines to compute these.

* `possible_outcomes`: array of XXX fixme

[Anaconda]: https://docs.conda.io/en/latest/miniconda.html
