#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Sep  5 18:23:54 2021

@author: lorenzopellis
"""

import numpy as np
np.random.seed(1)
import networkx as nx
from scipy import linalg as LA
import scipy.optimize as op

# Basic settings: qualities and groups
liq = ("age","sex") # List of individual qualities
niq = len(liq) # Number of individual qualities
lig = (((0,1),(2,3),tuple(range(4,15))),(("male"),("female"))) # List of individual groups (numbers refer to 5-year age bands)
nig = np.array([len(lig[iq]) for iq in range(niq)]) # Numbers in each group
nit = np.prod(nig) # Number of types
nirg = np.array(nig) - 1 # Number of relative groups
nic = np.sum(nirg) # Number of covariates

loq = ("serology","positive") # List of output qualities
noq = len(loq) # Number of output qualities
log = ((False,True),(False,True)) # List of output groups (but not consistent - should be 4 but then it's 3)

fmhs = 6 # Fixed maximum household size - discard all households larger than this
# fitpars = ['lambdaG','lambdaL','shape','eta','alpha','beta','gamma'] # List of parameters I want to fit
fitpars = ['lambdaG','lambdaL','shape','eta'] # List of parameters I want to fit
nindepchains = 1 # Can potentially run multiple independent optimisations from different user-specified starting points
saveevery = 5
maxsaved = 20
startpars = [{} for k in range(nindepchains)]
# Parameters: lambdaG = out
# mylastpoint = {'lambdaG': 0.5749439966837089, 'lambdaL': 0.04356322185670522, 'shape': 7.905944093759846, 'eta': 0.5939602854392884, 'alpha': ([1.14895509, 1.38107949, 1.00413733]), 'beta': ([1.00413733, 0.47469427, 0.55576318]), 'gamma': ([0.55576318, 3.42196313, 1.60259139])}
# mylastpoint = {'lambdaG': 0.5805278750277968, 'lambdaL': 0.05445326163107671, 'shape': 7.904057853969973, 'eta': 1.1903555147907272, 'alpha': ([1.19317426, 1.30642245, 1.03922087]), 'beta': ([1.03922087, 0.8333395 , 0.83402804]), 'gamma': ([0.83402804, 4.58651515, 1.8815987 ])}
# startpars[0] = mylastpoint
startpars[0] = {'lambdaG':np.exp(-1.0),'lambdaL':np.exp(-1.0),'shape':1.0,'eta':1.0,'alpha':np.ones(nic),'beta':np.ones(nic),'gamma':np.ones(nic)}
# startpars[0] = {'lambdaG':np.exp(-8.0),'lambdaL':np.exp(-8.0),'shape':1.0,'eta':np.exp(-5),'alpha':np.ones(nic),'beta':np.ones(nic),'gamma':np.ones(nic)}
# startpars[0] = {'lambdaG':np.exp(-8.0),'lambdaL':np.exp(-8.0),'shape':1.0,'eta':np.exp(-5),'alpha':[1/2,1,2],'beta':[1/3,1,3],'gamma':[1/5,1,5]}
# My favourites
# startpars[0] = {'lambdaG':0.33,'lambdaL':0.42,'shape':1.0,'eta':1.25#,'alpha':np.ones(nic),'beta':np.ones(nic),'gamma':np.ones(nic)}
natboundsdict = {
        'lambdaG':[-5.0, 0.0],
        'lambdaL':[-5.0, 0.0],
        'shape':[-2.0, 2.0],
        'eta':[-2.0, 2.0],
        'alpha':[[-2.0, 2.0]]*nic,
        'beta':[[-2.0, 2.0]]*nic,
        'gamma':[[-2.0, 2.0]]*nic
} # These bounds are in transformed (natural) space


# Function computing the right parameter combination of a type -- basic format and already exponentiating coefficients
# Covariate to types (c2t):
def c2t_basic(lic): 
    v = np.zeros(nit)
    v[0] = 1
    ccp = 0
    ctp = 1 # Current type position
    for iq in range(niq):
        vnew = np.append(1,lic[ccp:(ccp+nirg[iq])])
        vtemp = v[:ctp]
        # print(vnew)
        # print(vtemp)
        for j,vj in enumerate(vnew):
            v[(j*ctp):((j+1)*ctp)] = vtemp * vj
        ccp = ccp+nirg[iq]
        ctp = ctp*len(vnew)
    return v

c2t_basic(np.log([2,3,4]))

# Function giving a type t each individual in household
def findtype_basic(members,liq,niq,lig,nig):
    # v = np.zeros(len(members),dtype=int)
    v = [0 for x in range(len(members))]
    ig = np.zeros((niq,len(members)))
    for ii,i in enumerate(members):
        cc = 0 # cumulative counter
        for iq,q in enumerate(liq):
            # print(i)
            # print(q)
            # print(g.nodes[i][q])
            # print(lig[iq])
            # print([g.nodes[i][q] in lig[iq][x] for x in range(len(lig[iq]))])
            ig[iq,ii] = [mygraph.nodes[i][q] in lig[iq][x] for x in range(len(lig[iq]))].index(True)
            cc += ig[iq,ii] * np.prod(nig[:iq])
            # print(cc)
        v[ii] = int(cc)
    # print(v)
    return v

# Function calculating the likelihood for a single household
def NLLfun1H(hs,hpo,lG,lL,shape,eta,a,b,g):
    if (hs==1):
        pesc = np.exp(-lG*a)
        P = np.array([pesc,1-pesc])
        # for ij in range(lj):
        #     jv = alloutputs[ij,-hs:]
        #     nlBB = np.sum(lG*a[~jv])    
        #     for io in range(ij+1):
        #         ov = alloutputs[io,-hs:]
        #         if all(jv[ov]):
        #             MM[ij,io] = np.exp(nlBB)
        # Pcheck = LA.solve(MM,np.ones(lj))
        # print('Household of size 1. Check:',[P,Pcheck])
        NLL1H = -np.sum(np.log(P[hpo]))
    else:
        lj = 2**hs
        MM = np.zeros([lj,lj])
        LL = (lL/((hs-1)**eta))*np.outer(b,g)
        for ij in range(lj):
            jv = alloutputs[ij,-hs:]
            nlphiv = shape * np.log( 1 + np.sum(LL[~jv,:],0)/shape ) # negative log of phiv = (1 + sum(LL(nmjv,:),1)/gamsh ).^(-gamsh)
            nlBB = np.sum(lG*a[~jv])
    
            for io in range(ij+1):
                ov = alloutputs[io,-hs:]
                if all(jv[ov]):
                    MM[ij,io] = np.exp(np.sum(nlphiv[ov])+nlBB)
        try:
            P = LA.solve(MM,np.ones(lj))
            NLL1H = -np.sum(np.log(P[hpo]))
            if np.isnan(NLL1H):
                flag = 1
        except ValueError as e:
            NLL1H = np.inf
            print(MM)
            print(nlBB)
            print(nlphiv)
            print(LL)
            print(e)
    
    # NLL1H = -np.sum(np.log(P[hpo]))
    # print(NLL1H)
    
    return NLL1H
    
# Function preparing the parameters to run the likelihood for a single household, and then computing the overall likelihood
def NLLfun(Hdict,lambdaG=np.exp(-5.0),lambdaL=np.exp(-5.0),shape=1.0,eta=1.0,alpha=np.ones(nic),beta=np.ones(nic),gamma=np.ones(nic)):
    all_a = c2t_basic(alpha)
    all_b = c2t_basic(beta)
    all_g = c2t_basic(gamma)
    
    NLLvec = np.zeros(len(Hdict))
    for ih in range(len(Hdict)):
        # hs = Hdict[ih]['size']
        hmt = Hdict[ih]['type_of_members']
        a = all_a[hmt]
        b = all_b[hmt]
        g = all_g[hmt]
        # hpo = Hdict[ih]['possible_outcomes']
        # print("Household: ",ih)
        NLLvec[ih] = NLLfun1H(Hdict[ih]['size'],Hdict[ih]['possible_outcomes'],lambdaG,lambdaL,shape,eta,a,b,g)
        # print('Household',ih+1,'of',len(Hdict),'done! - NLL =',NLLvec[ih])
    
    NLL = np.sum(NLLvec)
    print(NLL)
    return NLL

# Function taking the vector of parameters in natural space (v) managed directly by the optimiser and transforming it into a dictionary (d) of parameter values that make sense to me
def parsv2d(x,allpars,fitpars):
    j = 0
    for i,k in enumerate(fitpars):
        if (k == 'alpha') or (k == 'beta') or (k == 'gamma'):
            allpars[k] = np.exp(x[j:(j+nic)])
            j = j+nic-1
        elif (k == 'eta'):
            allpars[k] = (4.0 / np.pi) * np.arctan(x[j]) + 1
            j = j+1
        else:
            allpars[k] = np.exp(x[j])
            j = j+1
    return allpars

# Function taking the dictionary (d) of parameter values that make sense to me and transforming it into a vector of parameters in natural space (v) managed directly by the optimiser
def parsd2v(allpars,fitpars):
    x = np.zeros(len(np.hstack([allpars[k] for k in fitpars])))
    j = 0
    for i,k in enumerate(fitpars):
        if (k == 'alpha') or (k == 'beta') or (k == 'gamma'):
            x[j:(j+nic)] = np.log(allpars[k])
            j = j+nic-1
        elif (k == 'eta'):
            x[j] = np.tan( (allpars[k]-1)*np.pi/4.0 ) #= (4.0 / np.pi) * np.arctan(x[j]) + 1
            j = j+1
        else:
            x[j] = np.log(allpars[k]) #= np.exp(x[j])
            j = j+1
    return x

# Function building the function to be directly optimised
def create_optimNLLfun(Hdict,startparslocal,fitpars):    
    def optimlink(x):
        # print(x)
        pars = startparslocal.copy()
        pars = parsv2d(x,pars,fitpars)
        NLL = NLLfun(Hdict,**pars)
        return NLL
    return optimlink

# Non-essential function checking I didn't screw up somethign while handling the data
def test_data(mydict,AHage,AHsex,AHtype,AHser,AHpos,AHotype):
    correctflag = np.zeros(len(mydict),dtype=bool)
    for ih in range(len(mydict)):
        ch = np.zeros(6,dtype=bool)
        ch[0] = all(np.array(AHage[ih]) == mydict[ih]['age_of_members'])
        ch[1] = all(np.array(AHsex[ih]) == mydict[ih]['sex_of_members'])
        ch[2] = all(np.array(AHtype[ih]) == mydict[ih]['type_of_members'])
        ch[3] = all(np.array(AHser[ih]) == mydict[ih]['serology'])
        ch[4] = all(np.array(AHpos[ih]) == mydict[ih]['positive'])
        ch[5] = True#all(np.array(AHotype[ih]) == mydict[ih]['outcome_types'])
        if all(ch): # Why does ~all(ch) NOT worrrrk????????
            correctflag[ih] = True
        else:
            print('Problems with household',ih)
            correctflag[ih] = False
    return correctflag

# Non-essential function to spit out a csv file of my data to check by eye I got the types right
# Legend for my original example of 3 age classes (0-10, 11-20, 21+, in real age) and 2 sexes (male and female):
    # 0-10 is the reference class for age
    # male is the reference class for sex
    # Household 3 has one adult male (type 2, as 0, 1 and 2 are the three age classes in increasing age for males)
    # one adult female (type 5, as 3, 4 and 5 are the three age classes for females) and one female teenager (type 4)
# In the "summary.csv" file:
    # -1 is used for padding and separating households (use conditional formatting in Excel to visually distinguish households, see "summary_saved.csv")
    # First column: household index
    # Second column: household size
    # Following columns: one per individual, and then padded with -1
    # For each household:
        # Row 1: the original age classes (in 5 year age band)
        # Row 2: male (0) or female (1)
        # Row 3: the type of each individual (see example above)
        # Row 4: serology available (1) or not (0)
        # Row 5: positive (1) or negative (0) - if serology is missing, it's 0
        # Row 6: output coded as serology and negative (0), serology and positive (2), or no serology (1) 
def display_data(mydict):
    tab = -np.ones((7*nAH,2+maxAHs),dtype=int)
    cc = 0
    for ih,h in enumerate(AH):
        tab[cc,0] = ih
        hs = AHs[ih]
        tab[cc,1] = hs
        tab[cc,2:(2+hs)] = mydict[ih]['age_of_members']
        tab[cc+1,0] = ih
        tab[cc+1,1] = hs
        tab[cc+1,2:(2+hs)] = mydict[ih]['sex_of_members']
        tab[cc+2,0] = ih
        tab[cc+2,1] = hs
        tab[cc+2,2:(2+hs)] = mydict[ih]['type_of_members']
        tab[cc+3,0] = ih
        tab[cc+3,1] = hs
        tab[cc+3,2:(2+hs)] = mydict[ih]['serology']
        tab[cc+4,0] = ih
        tab[cc+4,1] = hs
        tab[cc+4,2:(2+hs)] = mydict[ih]['positive']
        tab[cc+5,0] = ih
        tab[cc+5,1] = hs
        tab[cc+5,2:(2+hs)] = mydict[ih]['outcome_types']
        cc = cc + 7
    # tab.tofile("summary.csv",sep=",")
    np.savetxt("summary.csv", tab, 
                  delimiter = ",")
    # g.nodes[n]["age"]
    # 1 if g.nodes[n][“sex”] == female else 0

# Function creating other 2 output files, used to compute the initial parameter guesses
# File "outsummary.csv":
    # Column 1: household size (from 1 to 14)
    # Column 2: total number of households of each size
    # Column 3: fraction of household without any cases
    # Column 4: secondary attack rate (SAR) if all individuals without serology escaped infection
    # Column 5: SAR if half individuals without serology were infected
    # Column 6: SAR if all individuals without serology were infected
# File "outbysize.csv":
    # Column 1: household size (from 1 to 14)
    # Column 2: total number of households of each size
    # Other 68 columns (where 68 is the maximum number of households of the same size, i.e. 2):
        # For each household in turn, along a row, store the lowest possible final size for that household (i.e. number of confirmed positives)
        # Pad the rest of the row with 0s
def display_data_2(mydict):
    tabL = np.zeros((maxAHs+1,maxAHs+1),dtype=int)
    # tabM = np.zeros((maxAHs+1,maxAHs+1),dtype=int)
    # tabH = np.zeros((maxAHs+1,maxAHs+1),dtype=int)
    tabL[0,:] = np.arange(maxAHs+1)
    tabL[:,0] = np.arange(maxAHs+1)
    mydictbysize = [{} for i in range(maxAHs)]
    for ik in range(maxAHs):
        mydictbysize[ik]['s'] = ik+1 # Size
        mydictbysize[ik]['c'] = 0 # Counter
        mydictbysize[ik]['vL'] = [] # Vector of final size lower bound (Low)
        mydictbysize[ik]['vM'] = [] # Vector of final size mid point (Medium)
        mydictbysize[ik]['vH'] = [] # Vector of final size upper bound (High)
    
    # tab = -np.ones((7*nAH,2+maxAHs),dtype=int)
    # cc = 0
    for ih,h in enumerate(AH):
        hs = AHs[ih]
        nonser = np.sum(1-mydict[ih]['serology']) # the number of individuals without serology
        inf = np.sum(mydict[ih]['positive'])
        cc = mydictbysize[hs-1]['c'] # Counter for each household size
        mydictbysize[hs-1]['vL'].append(inf)
        mydictbysize[hs-1]['vM'].append(inf+nonser/2)
        mydictbysize[hs-1]['vH'].append(inf+nonser)
        mydictbysize[hs-1]['c'] = cc + 1
    print(mydictbysize)
    maxc = max([mydictbysize[ik]['c'] for ik in range(maxAHs)])
    outbysize = np.zeros((maxAHs,maxc+2))
    outsummary = np.zeros((maxAHs,6))
    for ik in range(maxAHs):
        outbysize[ik,0] = ik+1
        outbysize[ik,1] = mydictbysize[ik]['c']
        outbysize[ik,2:(2+mydictbysize[ik]['c'])] = mydictbysize[ik]['vL'] 
        outsummary[ik,0] = ik+1
        outsummary[ik,1] = mydictbysize[ik]['c']
        arr = np.array(mydictbysize[ik]['vL']) # Array of households' lowest possible final size
        valid = arr>0 # Extract only households with at least 1 case
        fs0 = sum(~valid)/len(valid) # Fraction of households with 0 cases (confirmed - I exclude those without serology)
        outsummary[ik,2] = fs0
        arrg0 = arr[valid] # Array of households' lowest possible final size that are greater than 0 (g0)
        ng0 = len(arrg0) # Number of households with final size certainly greater than 0
        outsummary[ik,3] = (np.sum(arrg0)-ng0)/(ng0*(ik)) # For a single household: SAR = (final size - 1)/(size - 1) 
        # For all, say n, households of size (ik+1): ( sum_{j=1}^{n} (final size of j - 1) ) / ( sum_{j=1}^{n} (size of j - 1) ) = (sum(final size of j) - n) / (ik*n)
        arr = np.array(mydictbysize[ik]['vM']) # Repeat for Medium final size
        arrg0 = arr[valid]
        outsummary[ik,4] = (np.sum(arrg0)-ng0)/(ng0*(ik)) # NOTE: ng0 is still the number of households that have at least 1 case in the Low final size case: is this correct??? How should I treat households with cases with no serology?
        arr = np.array(mydictbysize[ik]['vH']) # Repeat for High final size
        arrg0 = arr[valid]
        outsummary[ik,5] = (np.sum(arrg0)-ng0)/(ng0*(ik)) # NOTE: ng0 is still the number of households that have at least 1 case in the Low final size case: is this correct??? How should I treat households with cases with no serology?

    # tab.tofile("summary.csv",sep=",")
    np.savetxt("outbysize.csv", outbysize, fmt = '%1.2f', delimiter = ",")
    np.savetxt("outsummary.csv", outsummary, fmt = '%1.2f', delimiter = ",")
    # g.nodes[n]["age"]
    # 1 if g.nodes[n][“sex”] == female else 0
    eee = 0

# Read in the data
mygraph = nx.read_graphml("./minimal-stamford.graphml") # Read the network as a file in the current folder
AH = [n for n in mygraph if mygraph.nodes[n]["type"] == "household"] # List of all households
AHms = [list(nx.neighbors(mygraph, n)) for n in AH] # All households members, as a list of lists
nAH = len(AH)
AHs = [ len(ms) for ms in AHms ]
maxAHs = max(AHs)
AHdict = np.array([dict() for i in range(nAH)]) # 'orindex': 0, 'size': 0,'types':np.array
for ih,h in enumerate(AH):
    AHdict[ih]['index'] = ih
    AHdict[ih]['size'] = len(AHms[ih])
    AHdict[ih]['age_of_members'] = np.array([ mygraph.nodes[i]["age"] for i in AHms[ih] ])
    AHdict[ih]['sex_of_members'] = np.array(np.array([ mygraph.nodes[i]["sex"] for i in AHms[ih] ]) == 'female',dtype=int)
    AHdict[ih]['type_of_members'] = findtype_basic(AHms[ih],liq,niq,lig,nig)
    AHdict[ih]['serology'] = np.array([ mygraph.nodes[i]["serology"] for i in AHms[ih]],dtype=int)
    AHdict[ih]['positive'] = np.array([ (mygraph.nodes[i]["serology"] and mygraph.nodes[i]["positive"]) for i in AHms[ih]],dtype=int)
    AHdict[ih]['outcome_types'] = (1-AHdict[ih]['serology']) + 2*AHdict[ih]['positive']
    
# AHage = []
# AHsex = []
# AHser = []
# AHpos = []
# AHtype = []
# AHotype = []
# AH
# for ih,h in enumerate(AH):
#     # print([ g.nodes[ii]["age"] for ii in AHms[ih] ])
#     AHage.append([ mygraph.nodes[i]["age"] for i in AHms[ih] ])
#     temp = [ mygraph.nodes[i]["sex"] for i in AHms[ih] ]
#     AHsex.append([ int(x ==  "female") for x in temp ])
#     # AHsex.append([temp ==  "female" ])
#     v = findtype_basic(AHms[ih],liq,niq,lig,nig)
#     AHtype.append(v)
#     temp2 = [ mygraph.nodes[i]["serology"] for i in AHms[ih] ]
#     AHser.append([ int(x == True) for x in temp2 ])
#     temp3 = [ (mygraph.nodes[i]["serology"] and mygraph.nodes[i]["positive"]) for i in AHms[ih] ] 
#     AHpos.append([ int(x == True) for x in temp3 ])
#     AHotype.append([ int(x == True) for x in temp3 ]) # Let's keep things simple for the time being: infected are those observed and infected, others have escaped
# #    AHotype.append(np.add([ int(x == True) for x in temp2 ],[ int(x == True) for x in temp3 ]))
#     # Check correctednes
# data_OK = all(test_data(AHdict,AHage,AHsex,AHtype,AHser,AHpos,AHotype))
# display_data(AHdict)    
    
# display(AHage)
# display(AHsex)
# display(AHtype)




################ Main body of the function

ihtoolarge = [i for i,x in enumerate(AHs) if x>fmhs] # List of indices of households too big
shtoolarge = [AHs[i] for i in ihtoolarge]
nlh = len(ihtoolarge)
print(len(ihtoolarge),'households discarded')
for ihtl in ihtoolarge:
    print('Household ',ihtl)
    print('Size:',AHdict[ih]['size'])#AHs[ihtl])
    print('Types:',AHdict[ih]['type_of_members'])#AHtype[ihtl])
LH = [AH[i] for i in ihtoolarge];
ihsmallenough = [i for i,x in enumerate(AHs) if x<=fmhs]#np.array([3])#
H = [AH[i] for i in ihsmallenough]
nh = len(H)
print('Check:',nh,'+',nlh,'=',nh+nlh,'out of',len(AH),'household in total')
# Hdict = 

display_data_2(AHdict)
# Create largest output list based on fixed maximum household size
maxout = 2**fmhs
alloutputs = np.zeros((maxout,fmhs),dtype = bool)
for io in range(maxout):
    alloutputsbin = bin(io)[2:]
    alloutputs[io,-len(alloutputsbin):] = np.array(list(alloutputsbin)) == '1'


Hdict = np.array([dict() for i in range(nh)]) # 'orindex': 0, 'size': 0,'types':np.array
for ih,iho in enumerate(ihsmallenough):#enumerate(np.array([3])):#
    Hdict[ih]['original_index'] = iho
    Hdict[ih]['size'] = AHdict[iho]['size']#AHs[iho]
    Hdict[ih]['type_of_members'] = AHdict[iho]['type_of_members']#AHtype[iho]
    # Now create a vector with the decimal indices of outcomes compatible with observed data
    # This could in theory be made for all households (even very large ones) if I don't loop through all possible outcome
    # but go straight to the decimal values fiddling with binary notation - in this case I can put it above
    AHser_bool = np.array([mygraph.nodes[i]['serology'] for i in AHms[iho]])
    AHpos_bool = np.array([ (mygraph.nodes[i]['serology'] and mygraph.nodes[i]['positive']) for i in AHms[iho] ])
    num_not_observed = sum(~AHser_bool)
    len_vec_poss_outcomes = 2**num_not_observed
    vec_poss_outcomes = np.zeros(len_vec_poss_outcomes, dtype=int)
    Hs = AHs[iho]
    subvec_observed_output = AHpos_bool[AHser_bool]
    curr_index = 0
    for ij in range(2**Hs):
        jv = alloutputs[ij,-Hs:]
        if all(jv[AHser_bool] == subvec_observed_output):
            vec_poss_outcomes[curr_index] = ij
            curr_index = curr_index+1
    Hdict[ih]['possible_outcomes'] = vec_poss_outcomes

####### Optimisation
natbounds = np.vstack([natboundsdict[k] for k in fitpars]) # I don't think I'll change the bounds even if I change the starting point
parsMLE = [{} for k in range(nindepchains)]
for ic,sc in enumerate(startpars): # index chain, start of chain
    initvec = parsd2v(sc,fitpars)
    vecMLE = np.zeros((maxsaved+1,len(initvec)))
    vecMLE[0] = initvec
    optimNLLfun = create_optimNLLfun(Hdict,sc,fitpars)
    for iiter in range(maxsaved):
        result = op.minimize(optimNLLfun,vecMLE[iiter,],bounds=natbounds,options={'maxiter': saveevery, 'disp': True})
        vecMLE[iiter+1,:] = result.x
        print(result.x)
        np.savetxt("vecMLE.csv", vecMLE, delimiter = ",")
    parsMLE[ic] = parsv2d(vecMLE[-1,:],startpars[ic],fitpars)

parsMLE


# ####### Prepare the starting point
# llL = np.array([-8])
# llG = np.array([-8])
# # llLv = 2*linspace(-1,1,11) + llL; lx = length(llLv);
# # llGv = 1*linspace(-1,1,11) + llG; ly = length(llGv);
# # % lG = 0.027;%[0.025:0.001:0.028]; ly = length(lGv);
# # % ldv = 0.5:0.05:0.9; ly = length(ldv);
# # [X,Y] = meshgrid(llLv,llGv);
# # % [X,Y] = meshgrid(lLv,ldv);
# # Z = zeros(lx,ly);

# lgamsh = np.array([0])
# leta = np.array([-5])
# lap = np.zeros(sum(nirg))
# lbp = np.zeros(sum(nirg))
# lgp = np.zeros(sum(nirg))
# allpars = np.concatenate( (llG, llL, lgamsh, leta, lap, lbp, lgp) );
# varpars = np.array([ 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1 ]).astype(bool)
# pars0 = allpars[varpars]

# pars0 = np.array([startparsdict[k] for k in varpars])
# likelihood = make_lik(Hdict,startparsdict,varpars)

# bounds = np.column_stack([boundsdict[k] for k in varpars])

# final_pars = op.minimize(likelihood,pars0,bounds=bounds)


# ################ Other ways of doing things
# dicts = [ list(map(lambda n: g.nodes[n], ms)) for ms in members ]
# # lambda is a anonymous function
# dicts = [
#   { "size": len(ms),
#     "members": list(map(lambda n: g.nodes[n], ms)) }
#   for ms in members
# ]
# cats = [ list(map(findtype, ms)) for ms in members ]
# dicts = [
#   { "size": len(ms),
#     "members": [g.nodes[n] for n in ms] }
#   for ms in members
# ]
# # members ends up being a list of dictionaries 