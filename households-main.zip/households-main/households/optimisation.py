__all__ = ['maximise_gradient']

import scipy.optimize as op
import numpy as np
import logging
from households.likelihood import parsd2v, parsv2d, create_optimNLLfun

log = logging.getLogger("optimiser")

def maximise_gradient(Hdict, nllpars, startpars, fitpars, bounds, saveevery=5, maxsaved=20):
    """
    Performs maximisation of the likelihood by gradient descent.
    Returns a 2-tuple of the optimal set of parameters (the full set, including
    those not varied, and the optimisation history of only the varied
    parameters)
    """
    initvec = parsd2v(startpars, fitpars)
    log.info(f"Initial conditions:")
    for i,k in enumerate(fitpars):
        log.info(f"    {k}: {initvec[i]}")
    natbounds = np.vstack([bounds[k] for k in fitpars])
    log.info(f"Maximising within bounds")
    for i,k in enumerate(fitpars):
        log.info(f"    {k}: {natbounds[i]}")

    vecMLE = np.zeros((maxsaved+1, len(initvec)))
    vecMLE[0] = initvec
    optimNLLfun = create_optimNLLfun(Hdict, nllpars, startpars, fitpars)
    for iiter in range(maxsaved):
        result = op.minimize(optimNLLfun, vecMLE[iiter,], bounds=natbounds,
                             options = {'maxiter': saveevery, 'disp': False})

        log.info(f"Iteration {iiter*saveevery+result.nit} NLL={result.fun}")
        for i,k in enumerate(fitpars):
            log.info(f"    {k}: {result.x[i]}")

        vecMLE[iiter+1,:] = result.x

        if result.success:
            log.info("Success!")
            break

        #print(vecMLE[iiter+1])
    return parsv2d(vecMLE[-1,:], startpars, fitpars), vecMLE
