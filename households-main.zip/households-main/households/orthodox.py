"""
Input and output routines -- file reading and writing
"""

import networkx as nx
import numpy as np

def default_featurespec():
    """
    Produce a basic feature specification to map from the dictionary
    representation of households to a type vector in the space of
    features.
    """
    # Basic settings: qualities and groups
    liq = ("age","sex") # List of individual qualities
    # Number of individual qualities
    niq = len(liq)
    # List of individual groups (numbers refer to 5-year age bands)
    lig = (((0,1),(2,3),tuple(range(4,15))),(("male"),("female"))) 
    # Numbers in each group
    nig = np.array([len(lig[iq]) for iq in range(niq)])
    # Number of types 
    nit = np.prod(nig)
    # Number of relative groups
    nirg = np.array(nig) - 1
    # Number of covariates
    nic = np.sum(nirg)

    return {
      'liq': liq, 'niq': niq, 'lig': lig, 'nig': nig,
      'nit': nit, 'nirg': nirg, 'nic': nic
    }

def findtype_basic(g, members, liq, niq, lig, nig, **unused):
    """
    Function giving a type t each individual in household
    """
    # v = np.zeros(len(members),dtype=int)
    v = [0 for x in range(len(members))]
    ig = np.zeros((niq,len(members)))
    for ii,i in enumerate(members):
        cc = 0 # cumulative counter
        for iq,q in enumerate(liq):
            # print(i)
            # print(q)
            # print(g.nodes[i][q])
            # print(lig[iq])
            # print([g.nodes[i][q] in lig[iq][x] for x in range(len(lig[iq]))])
            ig[iq,ii] = [g.nodes[i][q] in lig[iq][x] for x in range(len(lig[iq]))].index(True)
            cc += ig[iq,ii] * np.prod(nig[:iq])
            # print(cc)
        v[ii] = int(cc)
    # print(v)
    return v

def orthodox_to_dict(g, featurespec=None):
    """
    Transforms a labelled graph in Orthodox format to a dictionary as
    expected by the household model.

    Returns a dictionary with keys integer household id and values a
    dictionary of household attributes.
    """
    if featurespec is None:
        featurespec = default_featurespec()

    # List of all households
    AH = [n for n in g if g.nodes[n]["type"] == "household"]
    # All households members, as a list of lists
    AHms = [list(nx.neighbors(g, n)) for n in AH]
    # Count of households
    nAH = len(AH)

    AHdict = {}
    for ih,h in enumerate(AH):
        members = list(nx.neighbors(g, h))
        Hs = len(members)
        d = {
            'index': h,
            'members': members,
            'size': Hs,
            'type_of_members': findtype_basic(g, members, **featurespec),
            'age_of_members': np.array([ g.nodes[m]["age"] for m in members ]),
            'sex_of_members': np.array(np.array([ g.nodes[m]["sex"] for m in members ]) == 'female', dtype=int),
            'serology': np.array([ g.nodes[m]["serology"] for m in members]),
            'positive': np.array([ (g.nodes[m]["serology"] and g.nodes[m]["positive"]) for m in members ])
        }
        d['outcome_types']: (1-d['serology']) + 2*d['positive']

        AHdict[ih] = d
    return AHdict
