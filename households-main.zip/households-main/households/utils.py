import numpy as np
import json

class memoize(object):
  """
  A decorator to remember the result of calling a function
  for some argument and actually compute the result only once.
  """
  def __init__(self):
    ## a mapping of arguments -> results
    self.k = {} 
  def __call__(self, f):
    ## memoised version of the function
    def m(*av):
      ## if we haven't seen the result for the
      ## given arguments before, run the function
      if av not in self.k:
        self.k[av] = f(*av)
      ## return the saved result
      return self.k[av]
    ## return the memoised version
    return m

@memoize()
def alloutputs(fmhs):
  """
  Returns a matrix of bit combinations up to the provided fixed maximum
  household size
  """
  maxout = 2**fmhs
  allout = np.zeros((maxout, fmhs),dtype = bool)
  for io in range(maxout):
    alloutbin = bin(io)[2:]
    allout[io,-len(alloutbin):] = np.array(list(alloutbin)) == '1'
  return allout

def tojson(d):
  jd = {}
  for k,v in d.items():
    if isinstance(v, np.ndarray):
      jd[k] = list(v)
    else:
      jd[k] = v
  return json.dumps(jd)

if __name__ == '__main__':

  from time import sleep

  @memoize()
  def test(n):
    sleep(5)
    return n + 1

  print("This might take a while...")
  print(test(1))
  print("This is much faster")
  print(test(1))


  ## equivalently... not using decorator syntax
  def test(n):
    sleep(5)
    return n + 1
  test = memoize()(test)

