import numpy as np
from scipy import linalg as LA
import logging
from households.utils import alloutputs

def outcomes(Hdict, fmhs):
    """
    Utility function.

    Modifies Hdict in-place to compute possible outcomes compatible with
    serology data. The presence or absence of serology data is expected
    to in the household dictionary as a boolean/int array under the "serology"
    key. Similarly, serology results are expected to be under the "positive"
    key. These arrays must be of the same length (the number of members of
    the household).

    Modifies Hdict in-place with the "possible_outcomes" key populated
    for each household.

    Returns the the modified Hdict
    """
    log = logging.getLogger("outcomes")

    for hh in Hdict.values():
        # Now create a vector with the decimal indices of outcomes compatible with observed data
        num_not_observed = sum(~hh["serology"])
        len_vec_poss_outcomes = 2**num_not_observed
        vec_poss_outcomes = np.zeros(len_vec_poss_outcomes, dtype=int)
        subvec_observed_output = hh["positive"][hh["serology"]]
        Hs = hh["size"]
        curr_index = 0
        for ij in range(2**Hs):
            jv = alloutputs(fmhs)[ij,-Hs:]
            if all(jv[hh["serology"]] == subvec_observed_output):
                vec_poss_outcomes[curr_index] = ij
                curr_index = curr_index+1
        hh['possible_outcomes'] = vec_poss_outcomes

        log.debug(f"Household {hh['index']}")
        log.debug(f"Serology {hh['serology']}")
        log.debug(f"Positive {hh['positive']}")
        log.debug(f"Outcomes {hh['possible_outcomes']}")

    return Hdict

def default_qualities():
    """
    Return a dictionary of groups and default qualities to be used as parameters

    liq - list of individual qualities
    lig - list of individual groups (numbers refer to 5 year age bands)
    loq - list of output qualities
    log - list of output groups (but not consistent - should be 4 but then it's 3) XXX what does that mean?
    """
    return {
        "liq": ("age","sex"),
        "lig": (((0,1),(2,3),tuple(range(4,15))),(("male"),("female"))),
        "loq": ("serology","positive"),
        "log": ((False,True),(False,True)),
    }

def derived_qualities(qs):
    """
    Compute derived qualities from the basic list. Modifies qs in-place and
    returns it.

    niq - number of individual qualities
    nig - number of individual groups
    nit - number of individual types
    nirg - nimber of relative groups
    nic - number of covariates
    noq - number of output qualities
    """
    qs["niq"] = len(qs["liq"]) # Number of individual qualities
    qs["nig"] = np.array([len(qs["lig"][iq]) for iq in range(qs["niq"])])
    qs["nit"] = np.prod(qs["nig"])
    qs["nirg"] = np.array(qs["nig"]) - 1
    qs["nic"] = np.sum(qs["nirg"])
    qs["noq"] = len(qs["loq"])
    return qs

def default_nll_args(qs, fmhs):
    """
    Return default arguments for the NLL function given
    qualities and groups
    """
    d = {
        "lambdaG": np.exp(-5.0),
        "lambdaL": np.exp(-5.0),
        "shape": 1.0,
        "eta": 1.0,
        "alpha": np.ones(qs["nic"]),
        "beta": np.ones(qs["nic"]),
        "gamma": np.ones(qs["nic"]),
        "fmhs": fmhs
    }
    d.update(qs)
    return d

def c2t_basic(lic, niq, nit, nirg, **kw):
    """
    Covariate to types (c2t):
    Function computing the right parameter combination of a type -- basic
    format and already exponentiating coefficients.

    Arguments are:
    - lic:
    - niq: number of individual qualities (integer)
    - nit: number of individual types (integer)
    """
    v = np.zeros(nit)
    v[0] = 1
    ccp = 0
    ctp = 1 # Current type position
    for iq in range(niq):
        vnew = np.append(1,lic[ccp:(ccp+nirg[iq])])
        vtemp = v[:ctp]
        # print(vnew)
        # print(vtemp)
        for j,vj in enumerate(vnew):
            v[(j*ctp):((j+1)*ctp)] = vtemp * vj
        ccp = ccp+nirg[iq]
        ctp = ctp*len(vnew)
    return v

def parsv2d(x,allpars,fitpars):
    """
    Function taking the vector of parameters in natural space (v) managed
    directly by the optimiser and transforming it into a dictionary (d) of
    parameter values that make sense to me
    """
    j = 0
    for i,k in enumerate(fitpars):
        if (k == 'alpha') or (k == 'beta') or (k == 'gamma'):
            allpars[k] = np.exp(x[j:(j+nic)])
            j = j+nic-1
        elif (k == 'eta'):
            allpars[k] = (4.0 / np.pi) * np.arctan(x[j]) + 1
            j = j+1
        else:
            allpars[k] = np.exp(x[j])
            j = j+1
    return allpars

def parsd2v(allpars,fitpars):
    """
    Function taking the dictionary (d) of parameter values that make sense to
    me and transforming it into a vector of parameters in natural space (v)
    managed directly by the optimiser
    """
    x = np.zeros(len(np.hstack([allpars[k] for k in fitpars])))
    j = 0
    for i,k in enumerate(fitpars):
        if (k == 'alpha') or (k == 'beta') or (k == 'gamma'):
            x[j:(j+nic)] = np.log(allpars[k])
            j = j+nic-1
        elif (k == 'eta'):
            x[j] = np.tan( (allpars[k]-1)*np.pi/4.0 ) #= (4.0 / np.pi) * np.arctan(x[j]) + 1
            j = j+1
        else:
            x[j] = np.log(allpars[k]) #= np.exp(x[j])
            j = j+1
    return x


def NLLfun1H(hs,hpo,lG,lL,shape,eta,a,b,g,fmhs,**kw):
    """
    Function calculating the likelihood for a single household
    """
    log = logging.getLogger("NLLfun1H")
    
    if (hs==1):
        pesc = np.exp(-lG*a)
        P = np.array([pesc,1-pesc])
        # for ij in range(lj):
        #     jv = alloutputs[ij,-hs:]
        #     nlBB = np.sum(lG*a[~jv])
        #     for io in range(ij+1):
        #         ov = alloutputs[io,-hs:]
        #         if all(jv[ov]):
        #             MM[ij,io] = np.exp(nlBB)
        # Pcheck = LA.solve(MM,np.ones(lj))
        # print('Household of size 1. Check:',[P,Pcheck])
        NLL1H = -np.sum(np.log(P[hpo]))
    else:
        lj = 2**hs
        MM = np.zeros([lj,lj])
        LL = (lL/((hs-1)**eta))*np.outer(b,g)
        for ij in range(lj):
            jv = alloutputs(fmhs)[ij,-hs:]
            nlphiv = shape * np.log( 1 + np.sum(LL[~jv,:],0)/shape ) # negative log of phiv = (1 + sum(LL(nmjv,:),1)/gamsh ).^(-gamsh)
            nlBB = np.sum(lG*a[~jv])

            for io in range(ij+1):
                ov = alloutputs(fmhs)[io,-hs:]
                if all(jv[ov]):
                    MM[ij,io] = np.exp(np.sum(nlphiv[ov])+nlBB)
        try:
            P = LA.solve(MM,np.ones(lj))
            if any(P[hpo] < 0):
                log.error(f"hpo: {hpo}")
                log.error(f"P[hpo]: {P[hpo]}")
                raise ValueError("Linear system produces negative values")
            NLL1H = -np.sum(np.log(P[hpo]))
            if np.isnan(NLL1H):
                flag = 1
        except ValueError as e:
            NLL1H = np.inf
            log.error(f"MM: {MM}")
            log.error(f"nlBB: {nlBB}")
            log.error(f"nlphiv: {nlphiv}")
            log.error(f"LL: {LL}")
            log.error(f"{e}")

    return NLL1H

def NLLfun(Hdict, lambdaG, lambdaL, shape, eta, alpha, beta, gamma, **kw):
    """
    Function preparing the parameters to run the likelihood for a single household, and then computing the overall likelihood
    """
    all_a = c2t_basic(alpha, **kw)
    all_b = c2t_basic(beta, **kw)
    all_g = c2t_basic(gamma, **kw)

    NLLvec = np.zeros(len(Hdict))
    for i, hid in enumerate(Hdict):
        # hs = Hdict[ih]['size']
        hmt = Hdict[hid]['type_of_members']
        a = all_a[hmt]
        b = all_b[hmt]
        g = all_g[hmt]
        # hpo = Hdict[ih]['possible_outcomes']
        # print("Household: ",ih)
        NLLvec[i] = NLLfun1H(Hdict[hid]['size'],Hdict[hid]['possible_outcomes'],lambdaG,lambdaL,shape,eta,a,b,g,**kw)
        # print('Household',ih+1,'of',len(Hdict),'done! - NLL =',NLLvec[ih])

    NLL = np.sum(NLLvec)
    # print(NLL)
    return NLL

def create_optimNLLfun(Hdict,defaults,startparslocal,fitpars):
    """
    Function building the function to be directly optimised.

    Arguments:
    - Household dictionary
    - default parameters to be pushed down (see default_nll_args() and default_qualities())
    - starting values for parameters (dictionary)
    - parameters to fit (dictionary)
    """
    def optimlink(x):
        # print(x)
        pars = defaults.copy()
        pars.update(startparslocal)
        pars = parsv2d(x,pars,fitpars)
        NLL = NLLfun(Hdict,**pars)
        return NLL
    return optimlink
