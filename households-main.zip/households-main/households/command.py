from argparse import ArgumentParser
import logging
import numpy as np
from households.likelihood import outcomes, default_qualities, derived_qualities, default_nll_args
from households.optimisation import maximise_gradient
from households.utils import tojson

def cli():
    parser = ArgumentParser("households")
    parser.add_argument("-i", "--input", required=True, help="Input data file")
    parser.add_argument("-f", "--format", default="orthodox", help="Graph data convention (default: orthodox)")
    parser.add_argument("-d", "--display", default=None, type=str, help="File basename for optional data summary")
    parser.add_argument("-m", "--fmhs", default=6, type=int, help="Fixed maximum household size")
    parser.add_argument("-o", "--output", default="fit", help="Output base filename")
    parser.add_argument("--maxsaved", default=20, metavar="M", type=int, help="Maximum number of recorded optimisation steps")
    parser.add_argument("--saveevery", default=5, metavar="N", type=int, help="Record optimisation every N steps")
    parser.add_argument("--fit", default="lambdaG,lambdaL,shape,eta", metavar="lambdaG,lambdaL,shape,eta", help="Comma separated list of parameters to fit")
    parser.add_argument("--log", default="INFO", help="Logging level")
    args = parser.parse_args()

    numeric_level = getattr(logging, args.log.upper(), None)
    if not isinstance(numeric_level, int):
        raise ValueError('Invalid log level: %s' % loglevel)
    logging.basicConfig(level=numeric_level, format='%(asctime)s %(levelname)s %(message)s')
    log = logging.getLogger("households")

    AHdict = None

    if args.format == "orthodox":
        import networkx as nx
        from households.orthodox import orthodox_to_dict
        log.info(f"Reading Orthodox format graphical data from {args.input}")
        g = nx.read_graphml(args.input)
        AHdict = orthodox_to_dict(g)

    assert AHdict is not None, "Could not create input dictionary"

    if args.display is not None:
        from households.data import display_data_2
        display_data_2(AHdict, args.display)

    ## filter out large households
    Hdict = { k:hh for k,hh in enumerate(AHdict.values()) if hh["size"] <= args.fmhs }

    log.info(f"Discarding {len(AHdict)-len(Hdict)} of {len(AHdict)} total households")
    for hh in [h for h in AHdict.values() if h["size"] > args.fmhs]:
        log.debug(f'Household index={hh["index"]} size={hh["size"]} types={hh["type_of_members"]}')

    log.info(f"Computing possible outcomes for each household")
    Hdict = outcomes(Hdict, args.fmhs)

    ## TODO: make this configurable
    qualities = derived_qualities(default_qualities())
    nllpars = default_nll_args(qualities, args.fmhs)

    log.info("Qualities and covariates:")
    for k,v in qualities.items():
        log.info(f"    {k}: {qualities[k]}")

    nic = qualities["nic"]
    startpars = {
        'lambdaG': 0.4, #np.exp(-1.0),
        'lambdaL': 1.0, #np.exp(-1.0),
        'shape':   1.0,
        'eta':     0.5,
        'alpha':   np.ones(nic),
        'beta':    np.ones(nic),
        'gamma':   np.ones(nic)
    }
    bounds = {
        'lambdaG': [-5.0, 0.0],
        'lambdaL': [-5.0, 0.0],
        'shape':   [-2.0, 2.0],
        'eta':     [-2.0, 2.0],
        'alpha':   [[-2.0, 2.0]]*nic,
        'beta':    [[-2.0, 2.0]]*nic,
        'gamma':   [[-2.0, 2.0]]*nic
    } # These bounds are in transformed (natural) space

    fitpars = args.fit.split(",")

    log.info(f"Fixed parameters:")
    for k,v in startpars.items():
        if k in fitpars: continue
        log.info(f"    {k}: {startpars[k]}")
    log.info(f"Fitting {fitpars} starting from (natural units):")
    for k,v in startpars.items():
        if k in fitpars:
            log.info(f"    {k}: {startpars[k]}")

    best, history = maximise_gradient(Hdict, nllpars, startpars, fitpars, bounds, args.saveevery, args.maxsaved)

    log.info("Writing output")
    fname = f"{args.output}-best.json"
    log.info(f"    {fname}")
    with open(fname, "w+") as fp:
        fp.write(tojson(best))
    fname = f"{args.output}-history.csv"
    log.info(f"    {fname}")
    np.savetxt(fname, history, delimiter=",")
