import numpy as np

# Non-essential function to spit out a csv file of my data to check by eye I got the types right
# Legend for my original example of 3 age classes (0-10, 11-20, 21+, in real age) and 2 sexes (male and female):
    # 0-10 is the reference class for age
    # male is the reference class for sex
    # Household 3 has one adult male (type 2, as 0, 1 and 2 are the three age classes in increasing age for males)
    # one adult female (type 5, as 3, 4 and 5 are the three age classes for females) and one female teenager (type 4)
# In the "summary.csv" file:
    # -1 is used for padding and separating households (use conditional formatting in Excel to visually distinguish households, see "summary_saved.csv")
    # First column: household index
    # Second column: household size
    # Following columns: one per individual, and then padded with -1
    # For each household:
        # Row 1: the original age classes (in 5 year age band)
        # Row 2: male (0) or female (1)
        # Row 3: the type of each individual (see example above)
        # Row 4: serology available (1) or not (0)
        # Row 5: positive (1) or negative (0) - if serology is missing, it's 0
        # Row 6: output coded as serology and negative (0), serology and positive (2), or no serology (1) 

## XXX this appears to be unused
def display_data(mydict, filebase):
    """
    First argument is the household data dictionary, second argument is a basename for the
    output file.
    """
    tab = -np.ones((7*nAH,2+maxAHs),dtype=int)
    cc = 0
    for ih,h in enumerate(AH):
        tab[cc,0] = ih
        hs = AHs[ih]
        tab[cc,1] = hs
        tab[cc,2:(2+hs)] = mydict[ih]['age_of_members']
        tab[cc+1,0] = ih
        tab[cc+1,1] = hs
        tab[cc+1,2:(2+hs)] = mydict[ih]['sex_of_members']
        tab[cc+2,0] = ih
        tab[cc+2,1] = hs
        tab[cc+2,2:(2+hs)] = mydict[ih]['type_of_members']
        tab[cc+3,0] = ih
        tab[cc+3,1] = hs
        tab[cc+3,2:(2+hs)] = mydict[ih]['serology']
        tab[cc+4,0] = ih
        tab[cc+4,1] = hs
        tab[cc+4,2:(2+hs)] = mydict[ih]['positive']
        tab[cc+5,0] = ih
        tab[cc+5,1] = hs
        tab[cc+5,2:(2+hs)] = mydict[ih]['outcome_types']
        cc = cc + 7
    # tab.tofile("summary.csv",sep=",")
    np.savetxt(f"{filebase}-summary.csv", tab, 
                  delimiter = ",")
    # g.nodes[n]["age"]
    # 1 if g.nodes[n][“sex”] == female else 0

# Function creating other 2 output files, used to compute the initial parameter guesses
# File "outsummary.csv":
    # Column 1: household size (from 1 to 14)
    # Column 2: total number of households of each size
    # Column 3: fraction of household without any cases
    # Column 4: secondary attack rate (SAR) if all individuals without serology escaped infection
    # Column 5: SAR if half individuals without serology were infected
    # Column 6: SAR if all individuals without serology were infected
# File "outbysize.csv":
    # Column 1: household size (from 1 to 14)
    # Column 2: total number of households of each size
    # Other 68 columns (where 68 is the maximum number of households of the same size, i.e. 2):
        # For each household in turn, along a row, store the lowest possible final size for that household (i.e. number of confirmed positives)
        # Pad the rest of the row with 0s

def display_data_2(mydict, filebase):
    """
    First argument is the household data dictionary, second argument is a basename for the
    output file.
    """
    maxAHs = max(hh['size'] for hh in mydict.values())
    tabL = np.zeros((maxAHs+1,maxAHs+1),dtype=int)
    # tabM = np.zeros((maxAHs+1,maxAHs+1),dtype=int)
    # tabH = np.zeros((maxAHs+1,maxAHs+1),dtype=int)
    tabL[0,:] = np.arange(maxAHs+1)
    tabL[:,0] = np.arange(maxAHs+1)
    mydictbysize = [{} for i in range(maxAHs)]
    for ik in range(maxAHs):
        mydictbysize[ik]['s'] = ik+1 # Size
        mydictbysize[ik]['c'] = 0 # Counter
        mydictbysize[ik]['vL'] = [] # Vector of final size lower bound (Low)
        mydictbysize[ik]['vM'] = [] # Vector of final size mid point (Medium)
        mydictbysize[ik]['vH'] = [] # Vector of final size upper bound (High)

    # tab = -np.ones((7*nAH,2+maxAHs),dtype=int)
    # cc = 0
    for h in mydict.values():
        hs = h['size']
        nonser = np.sum(1-h['serology']) # the number of individuals without serology
        inf = np.sum(h['positive'])
        cc = mydictbysize[hs-1]['c'] # Counter for each household size
        mydictbysize[hs-1]['vL'].append(inf)
        mydictbysize[hs-1]['vM'].append(inf+nonser/2)
        mydictbysize[hs-1]['vH'].append(inf+nonser)
        mydictbysize[hs-1]['c'] = cc + 1
    print(mydictbysize)
    maxc = max([mydictbysize[ik]['c'] for ik in range(maxAHs)])
    outbysize = np.zeros((maxAHs,maxc+2))
    outsummary = np.zeros((maxAHs,6))
    for ik in range(maxAHs):
        outbysize[ik,0] = ik+1
        outbysize[ik,1] = mydictbysize[ik]['c']
        outbysize[ik,2:(2+mydictbysize[ik]['c'])] = mydictbysize[ik]['vL'] 
        outsummary[ik,0] = ik+1
        outsummary[ik,1] = mydictbysize[ik]['c']
        arr = np.array(mydictbysize[ik]['vL']) # Array of households' lowest possible final size
        valid = arr>0 # Extract only households with at least 1 case
        fs0 = sum(~valid)/len(valid) # Fraction of households with 0 cases (confirmed - I exclude those without serology)
        outsummary[ik,2] = fs0
        arrg0 = arr[valid] # Array of households' lowest possible final size that are greater than 0 (g0)
        ng0 = len(arrg0) # Number of households with final size certainly greater than 0
        outsummary[ik,3] = (np.sum(arrg0)-ng0)/(ng0*(ik)) # For a single household: SAR = (final size - 1)/(size - 1) 
        # For all, say n, households of size (ik+1): ( sum_{j=1}^{n} (final size of j - 1) ) / ( sum_{j=1}^{n} (size of j - 1) ) = (sum(final size of j) - n) / (ik*n)
        arr = np.array(mydictbysize[ik]['vM']) # Repeat for Medium final size
        arrg0 = arr[valid]
        outsummary[ik,4] = (np.sum(arrg0)-ng0)/(ng0*(ik)) # NOTE: ng0 is still the number of households that have at least 1 case in the Low final size case: is this correct??? How should I treat households with cases with no serology?
        arr = np.array(mydictbysize[ik]['vH']) # Repeat for High final size
        arrg0 = arr[valid]
        outsummary[ik,5] = (np.sum(arrg0)-ng0)/(ng0*(ik)) # NOTE: ng0 is still the number of households that have at least 1 case in the Low final size case: is this correct??? How should I treat households with cases with no serology?

    # tab.tofile("summary.csv",sep=",")
    np.savetxt(f"{filebase}-outbysize.csv", outbysize, fmt = '%1.2f', delimiter = ",")
    np.savetxt(f"{filebase}-outsummary.csv", outsummary, fmt = '%1.2f', delimiter = ",")
    # g.nodes[n]["age"]
    # 1 if g.nodes[n][“sex”] == female else 0
    eee = 0

# AHage = []
# AHsex = []
# AHser = []
# AHpos = []
# AHtype = []
# AHotype = []
# AH
# for ih,h in enumerate(AH):
#     # print([ g.nodes[ii]["age"] for ii in AHms[ih] ])
#     AHage.append([ mygraph.nodes[i]["age"] for i in AHms[ih] ])
#     temp = [ mygraph.nodes[i]["sex"] for i in AHms[ih] ]
#     AHsex.append([ int(x ==  "female") for x in temp ])
#     # AHsex.append([temp ==  "female" ])
#     v = findtype_basic(AHms[ih],liq,niq,lig,nig)
#     AHtype.append(v)
#     temp2 = [ mygraph.nodes[i]["serology"] for i in AHms[ih] ]
#     AHser.append([ int(x == True) for x in temp2 ])
#     temp3 = [ (mygraph.nodes[i]["serology"] and mygraph.nodes[i]["positive"]) for i in AHms[ih] ] 
#     AHpos.append([ int(x == True) for x in temp3 ])
#     AHotype.append([ int(x == True) for x in temp3 ]) # Let's keep things simple for the time being: infected are those observed and infected, others have escaped
# #    AHotype.append(np.add([ int(x == True) for x in temp2 ],[ int(x == True) for x in temp3 ]))
#     # Check correctednes
# data_OK = all(test_data(AHdict,AHage,AHsex,AHtype,AHser,AHpos,AHotype))
# display_data(AHdict)    
    
# display(AHage)
# display(AHsex)
# display(AHtype)
