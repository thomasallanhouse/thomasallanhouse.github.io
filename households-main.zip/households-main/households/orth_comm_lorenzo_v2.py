#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Sep  5 18:23:54 2021

@author: lorenzopellis
"""

import numpy as np
np.random.seed(1)
import networkx as nx
from scipy import linalg as LA
import scipy.optimize as op

from households.likelihood import default_qualities, derived_qualities


fmhs = 6 # Fixed maximum household size - discard all households larger than this
# fitpars = ['lambdaG','lambdaL','shape','eta','alpha','beta','gamma'] # List of parameters I want to fit
fitpars = ['lambdaG','lambdaL','shape','eta'] # List of parameters I want to fit
nindepchains = 1 # Can potentially run multiple independent optimisations from different user-specified starting points
saveevery = 5
maxsaved = 20
startpars = [{} for k in range(nindepchains)]

qualities = derived_qualities(default_qualities())
nic = qualities["nic"]

# Parameters: lambdaG = out
# mylastpoint = {'lambdaG': 0.5749439966837089, 'lambdaL': 0.04356322185670522, 'shape': 7.905944093759846, 'eta': 0.5939602854392884, 'alpha': ([1.14895509, 1.38107949, 1.00413733]), 'beta': ([1.00413733, 0.47469427, 0.55576318]), 'gamma': ([0.55576318, 3.42196313, 1.60259139])}
# mylastpoint = {'lambdaG': 0.5805278750277968, 'lambdaL': 0.05445326163107671, 'shape': 7.904057853969973, 'eta': 1.1903555147907272, 'alpha': ([1.19317426, 1.30642245, 1.03922087]), 'beta': ([1.03922087, 0.8333395 , 0.83402804]), 'gamma': ([0.83402804, 4.58651515, 1.8815987 ])}
# startpars[0] = mylastpoint
startpars[0] = {'lambdaG':np.exp(-1.0),'lambdaL':np.exp(-1.0),'shape':1.0,'eta':1.0,'alpha':np.ones(nic),'beta':np.ones(nic),'gamma':np.ones(nic)}
# startpars[0] = {'lambdaG':np.exp(-8.0),'lambdaL':np.exp(-8.0),'shape':1.0,'eta':np.exp(-5),'alpha':np.ones(nic),'beta':np.ones(nic),'gamma':np.ones(nic)}
# startpars[0] = {'lambdaG':np.exp(-8.0),'lambdaL':np.exp(-8.0),'shape':1.0,'eta':np.exp(-5),'alpha':[1/2,1,2],'beta':[1/3,1,3],'gamma':[1/5,1,5]}
# My favourites
# startpars[0] = {'lambdaG':0.33,'lambdaL':0.42,'shape':1.0,'eta':1.25#,'alpha':np.ones(nic),'beta':np.ones(nic),'gamma':np.ones(nic)}
natboundsdict = {
        'lambdaG':[-5.0, 0.0],
        'lambdaL':[-5.0, 0.0],
        'shape':[-2.0, 2.0],
        'eta':[-2.0, 2.0],
        'alpha':[[-2.0, 2.0]]*nic,
        'beta':[[-2.0, 2.0]]*nic,
        'gamma':[[-2.0, 2.0]]*nic
} # These bounds are in transformed (natural) space


# Non-essential function checking I didn't screw up somethign while handling the data
def test_data(mydict,AHage,AHsex,AHtype,AHser,AHpos,AHotype):
    correctflag = np.zeros(len(mydict),dtype=bool)
    for ih in range(len(mydict)):
        ch = np.zeros(6,dtype=bool)
        ch[0] = all(np.array(AHage[ih]) == mydict[ih]['age_of_members'])
        ch[1] = all(np.array(AHsex[ih]) == mydict[ih]['sex_of_members'])
        ch[2] = all(np.array(AHtype[ih]) == mydict[ih]['type_of_members'])
        ch[3] = all(np.array(AHser[ih]) == mydict[ih]['serology'])
        ch[4] = all(np.array(AHpos[ih]) == mydict[ih]['positive'])
        ch[5] = True#all(np.array(AHotype[ih]) == mydict[ih]['outcome_types'])
        if all(ch): # Why does ~all(ch) NOT worrrrk????????
            correctflag[ih] = True
        else:
            print('Problems with household',ih)
            correctflag[ih] = False
    return correctflag


################ Main body of the function

# Read in the data
from households.orthodox import orthodox_to_dict
from households.data import display_data, display_data_2

mygraph = nx.read_graphml('./minimal-stamford.graphml') # Read the network as a file in the current folder
AHdict = orthodox_to_dict(mygraph)

# households that are too large
toolarge = [hh for hh in filter(lambda hh: hh["size"] > fmhs, AHdict.values())]

print(len(toolarge), 'Households discarded')
for hh in toolarge:
    print('Household ', hh['index'])
    print('Size:', hh['size'])
    print('Types:', hh['type_of_members'])

# households that are too large
smallenough = [hh for hh in filter(lambda hh: hh["size"] <= fmhs, AHdict.values())]

nh = len(smallenough)
nlh = len(toolarge)
th = len(AHdict)

assert nh + nlh == th, f'Check: {nh} + {nlh} = {nh+nlh} out of {th}  household in total'

display_data_2(AHdict, "legacy")

from households.likelihood import outcomes

## filter out large households
Hdict = { k:hh for k,hh in enumerate(AHdict.values()) if hh["size"] <= fmhs }
Hdict = outcomes(Hdict, fmhs)

from households.likelihood import c2t_basic, parsd2v, create_optimNLLfun, default_nll_args

nllpars = default_nll_args(qualities, fmhs)

####### Optimisation
natbounds = np.vstack([natboundsdict[k] for k in fitpars]) # I don't think I'll change the bounds even if I change the starting point
parsMLE = [{} for k in range(nindepchains)]
for ic,sc in enumerate(startpars): # index chain, start of chain
    initvec = parsd2v(sc,fitpars)
    vecMLE = np.zeros((maxsaved+1,len(initvec)))
    vecMLE[0] = initvec
    optimNLLfun = create_optimNLLfun(Hdict,nllpars,sc,fitpars)
    for iiter in range(maxsaved):
        result = op.minimize(optimNLLfun,vecMLE[iiter,],bounds=natbounds,options={'maxiter': saveevery, 'disp': True})
        vecMLE[iiter+1,:] = result.x
        print(result.x)
        np.savetxt("vecMLE.csv", vecMLE, delimiter = ",")
    parsMLE[ic] = parsv2d(vecMLE[-1,:],startpars[ic],fitpars)

parsMLE


# ####### Prepare the starting point
# llL = np.array([-8])
# llG = np.array([-8])
# # llLv = 2*linspace(-1,1,11) + llL; lx = length(llLv);
# # llGv = 1*linspace(-1,1,11) + llG; ly = length(llGv);
# # % lG = 0.027;%[0.025:0.001:0.028]; ly = length(lGv);
# # % ldv = 0.5:0.05:0.9; ly = length(ldv);
# # [X,Y] = meshgrid(llLv,llGv);
# # % [X,Y] = meshgrid(lLv,ldv);
# # Z = zeros(lx,ly);

# lgamsh = np.array([0])
# leta = np.array([-5])
# lap = np.zeros(sum(nirg))
# lbp = np.zeros(sum(nirg))
# lgp = np.zeros(sum(nirg))
# allpars = np.concatenate( (llG, llL, lgamsh, leta, lap, lbp, lgp) );
# varpars = np.array([ 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1 ]).astype(bool)
# pars0 = allpars[varpars]

# pars0 = np.array([startparsdict[k] for k in varpars])
# likelihood = make_lik(Hdict,startparsdict,varpars)

# bounds = np.column_stack([boundsdict[k] for k in varpars])

# final_pars = op.minimize(likelihood,pars0,bounds=bounds)


# ################ Other ways of doing things
# dicts = [ list(map(lambda n: g.nodes[n], ms)) for ms in members ]
# # lambda is a anonymous function
# dicts = [
#   { "size": len(ms),
#     "members": list(map(lambda n: g.nodes[n], ms)) }
#   for ms in members
# ]
# cats = [ list(map(findtype, ms)) for ms in members ]
# dicts = [
#   { "size": len(ms),
#     "members": [g.nodes[n] for n in ms] }
#   for ms in members
# ]
# # members ends up being a list of dictionaries 
